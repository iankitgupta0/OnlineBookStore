<div id="footer-wrap">
	<p id="legal">(c) 2017 OurSite. Design by <a href="developer.php">Ankit Gupta</a>.</p>
</div>
	