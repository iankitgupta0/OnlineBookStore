<?php session_start();?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
		<?php
			 include("includes/head.inc.php");
		?>
</head>

<body>
			<!-- start header -->
				<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>
				</div>
				
				<div id="logo-wrap">
					<div id="logo">
							<?php
								include("includes/logo.inc.php");
							?>
					</div>
				</div>
			<!-- end header -->
			
			<!-- start page -->

				<div id="page">
					<!-- start content -->
					<div id="content">
						<div class="post">
							<h1 class="title">Welcome 
							<?php 
								if(isset($_SESSION['status']))
								{
									echo $_SESSION['unm']; 
								}
								else
								{	
									echo 'to the Online BookShop Store';
								}
							?>
							</h1>
							<div class="entry">
								<br>
								<p>
								The OnlineBookshop is my 5th semester project in Open source technologies. Project is made by <a href="developer.php"><font color="purple">11501815 <br>Ankit Gupta</font></a>.
								and It will be submitted to Mr. Balijt Saini.<br>
								</p>
								<br>
								<object width="550" height="400">
								<embed src="3DMenu.swf" width="550" height="400">
								</embed>
								</object>
								<br><br>
								<p>
								The website is dedicated to book lovers who found difficulties to search for a book . Here user can found different variety of books and 
								if any of the book is not available they can request it and we make it available as soon as possible. 
							</p>		
							</div>
							
						</div>
						
					</div>
					<!-- end content -->
								<!-- start sidebar -->
				<div id="sidebar">
							<?php
								include("includes/search.inc.php");
							?>
					</div>
		
					<!-- end sidebar -->
					<div style="clear: both;">&nbsp;</div>
				</div> 
			<!-- end page -->
			
		<!-- start footer --> 
				<div id="footer">
							<?php
								include("includes/footer.inc.php");
							?>
				</div>
			<!-- end footer -->
</body>
</html>
